/*I'm not sure if we're supposed to reference borrowed code. But google, stackoverflow, and ChatGPT
was heavily utilized for preparing some of the javascript*/
// Inputs a map object, which should allow users to save username and password
const users = new Map();

/*A large portion of code can't be verified until a databse is set up to actually save 
username and password tokens. So, most of this javascript will only serve use in the final
version of this webpage for end of the semester*/

// Adds an event listener to the login form. This code will manage the form submission for login.
document.getElementById("login-form")?.addEventListener("submit", (e) => {
    e.preventDefault();

    // Get the entered username and password from the form inputs
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Checks if entered username and password match any existing users.
    if (users.has(username) && users.get(username) === password) {
        // If login is sucessful, the user will be redirected to the home page. 
        window.location.href = "/home";
    } else {
        // Failed login: shows an error message
        alert("Incorrect username or password.");
    }
});

// This code adds an event lister to account creation instead. This will manage the form submission for account creation.
document.getElementById("create-account")?.addEventListener("click", () => {
    // Prompts the user to enter their desired username
    const username = prompt("Enter your desired username:");
    if (username && !users.has(username)) {
        // Prompts the user to enter their desired password
        const password = prompt("Enter your desired password:");
        if (password) {
            /* Similar to primary key in database, this portion utilizes a map object
            that assigns a unique key to the username and password, which then pairs them. */
            users.set(username, password);
            // Successful account creation: redirects user to home page
            window.location.href = "/home";
        } else {
            // Failed account creation: shows an error message if password field is not given a value
            alert("Password cannot be empty.");
        }
    } else {
        // Failed account creation: shows an error message for invalid username
        alert("Username is either an invalid entry or is already taken.");
    }
});

// Function that enables profile editing features (profile picture and summary text)
function enableProfileEditing() {
  const profilePicture = document.getElementById("profile-picture");
  const summaryText = document.getElementById("summary-text");

  // Adds an event listener to the profile picture to handle image uploading
  profilePicture.addEventListener("click", () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          /* This portion still needs to be revised. However, the purpoes of this code would be
          to update the profile picture's background image with a new uploaded image */
          profilePicture.style.backgroundImage = `url(${e.target.result})`;
        };
        reader.readAsDataURL(file);
      }
    });
    input.click();
  });

  // Adds an event listeners to the summary text that can enable or disable summary text editing
  summaryText.addEventListener("click", () => {
    summaryText.contentEditable = "true";
    summaryText.focus();
  });

  summaryText.addEventListener("blur", () => {
    summaryText.contentEditable = "false";
  });
}

/* Calls the enableProfileEditing function after a successful login or account creation
so the user's profile can be edited */
enableProfileEditing();







