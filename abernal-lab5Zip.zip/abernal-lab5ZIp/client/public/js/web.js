/* This portion of code took plenty of effort and google. This document utilized youtube tutorials, stack overflow, ChatGPT, 
code academy, and other resources. */ 

// Inputs a map object, which should allow users to save username and password
const users = new Map();

/*A large portion of this code can not be verified until a databse is set up (that is able to save 
username and password tokens). So, most of this javascript will only serve use in the final
version of the webpage, or it may be scrapped altogether for server side duties.*/

// Adds an event listener to the login form. This code will manage the form submission for login.
document.getElementById("login-form")?.addEventListener("submit", (e) => {
    e.preventDefault();

    // Retrieves entered username and password from the form inputs
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Checks if entered username and password match any existing users.
    if (users.has(username) && users.get(username) === password) {
        // If login is sucessful, the user will be redirected to the home page. 
        window.location.href = "/home";
    } else {
        // Failed login: shows an error message
        alert("Incorrect username or password.");
    }
});

// This code adds an event lister to the account creation. This will manage the form submission for account creation.
document.getElementById("create-account")?.addEventListener("click", () => {
    // Prompts the user to enter their desired username
    const username = prompt("Enter your desired username:");
    if (username && !users.has(username)) {
        // Prompts the user to enter their desired password
        const password = prompt("Enter your desired password:");
        if (password) {
            // This portion utilizes a map object, then the "set" portion provides a key value to pair both username and password
            users.set(username, password);
            // Successful account creation: redirects user to home page
            window.location.href = "/home";
        } else {
            // Failed account creation: shows an error message if password field is not given a value
            alert("Password cannot be empty.");
        }
    } else {
        // Failed account creation: shows an error message for invalid username
        alert("Username is either an invalid entry or is already taken.");
    }
});

// Function that enables profile editing features (profile picture and summary text)
function enableProfileEditing() {
  const profilePicture = document.getElementById("profile-picture");
  const summaryText = document.getElementById("summary-text");

  // Adds an event listener to the profile picture to handle image uploading
//This portion of code now works, however, it was revised after the presentation
profilePicture.addEventListener("click", () => {
  //Creates a new input element for file selection
  const input = document.createElement("input");
  //Sets input type to file and accepts only image files
  input.type = "file";
  input.accept = "image/*";
  //Provides event listener to input element
  input.addEventListener("change", (e) => {
    //Receives first chosen file 
    const file = e.target.files[0];
    if (file) {
      //Checks selected file then creates new instance to read image
      const reader = new FileReader();
      //Adds event listener to reader instance
      reader.onload = (e) => {
        //Sets profile picture background with uploaded image
        profilePicture.style.backgroundImage = `url(${e.target.result})`;
        profilePicture.style.backgroundSize = "cover"; // NEW CODE - applies background-size property to cover whole element
        profilePicture.style.backgroundPosition = "center"; // NEW CODE - centers the image
      };
      reader.readAsDataURL(file); //Reads file as data URL
    }
  });
  input.click(); //Initiates file with input click event
});

  // Adds an event listeners to the summary text that can enable or disable summary text editing
  summaryText.addEventListener("click", () => {
    summaryText.contentEditable = "true";
    summaryText.focus();
  });

  summaryText.addEventListener("blur", () => {
    summaryText.contentEditable = "false";
  });
}

/* Calls the enableProfileEditing function after a successful login or account creation
so the user's profile can be edited */
enableProfileEditing();







